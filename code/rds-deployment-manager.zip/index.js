"use strict";

const aws = require("aws-sdk");

module.exports.handler = async(event, context, callback) => {
  console.log(event);
  callback();
};