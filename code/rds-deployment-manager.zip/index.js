"use strict";

const AWS = require("aws-sdk");
const autoscaling = new AWS.AutoScaling();

module.exports.handler = async(event, context, callback) => {
  console.log(event);
  if(event.detail && event.detail.LifecycleActionToken) { 
        await autoscaling.completeLifecycleAction({
        LifecycleHookName: event.detail.LifecycleHookName, AutoScalingGroupName: event.detail.AutoScalingGroupName,
        LifecycleActionToken: event.detail.LifecycleActionToken, LifecycleActionResult: 'CONTINUE'
      }).promise().catch(err => console.log(err));
  }
  callback();
};